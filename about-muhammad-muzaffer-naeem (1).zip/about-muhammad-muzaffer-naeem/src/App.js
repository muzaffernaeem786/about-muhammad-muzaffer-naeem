import React, { useEffect, useRef, useState } from 'react';
import QRCode from 'qrcode.react';
import './App.css';

const NAME = 'MUHAMMAD MUZAFFER NAEEM';
const TITLE = 'About Muhammad Muzaffer Naeem';
const TAGLINE = 'Ethical Hacker & Security Researcher AND REPORTER OF SCAM';
const BIO = `I am a passionate Ethical Hacker dedicated to uncovering vulnerabilities, securing digital spaces, and exposing scams. With a sharp eye for detail and a commitment to cyber safety, I collaborate with like‑minded professionals to build a safer internet.`;
const PHOTO_URL = 'https://i.ibb.co/0pYj5g5g/LOGO-png.jpg';

const CONTACTS = [
  { label: 'WhatsApp', data: '+923362419952' },
  { label: 'WS Channel', data: 'https://whatsapp.com/channel/0029VbB1fEk6buMHnqjGtK22' },
  { label: 'TikTok', data: 'https://www.tiktok.com/@muziedits79?_t=ZS-8ydFM8t7WDq&_r=1' },
];

export default function App(){
  const canvasRef = useRef(null);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    // Matrix rain
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let w = canvas.width = window.innerWidth;
    let h = canvas.height = window.innerHeight;
    const chars = 'アカサタナハマヤラワ0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const fontSize = 16;
    const columns = Math.floor(w / fontSize);
    const drops = Array(columns).fill(1);

    const draw = () => {
      ctx.fillStyle = 'rgba(10, 15, 13, 0.05)';
      ctx.fillRect(0, 0, w, h);
      ctx.fillStyle = '#22de29';
      ctx.font = fontSize + 'px Share Tech Mono';
      for(let i=0;i<drops.length;i++){
        const text = chars[Math.floor(Math.random()*chars.length)];
        ctx.fillText(text, i*fontSize, drops[i]*fontSize);
        if(drops[i]*fontSize > h && Math.random() > 0.975){
          drops[i] = 0;
        }
        drops[i]++;
      }
      requestAnimationFrame(draw);
    };
    draw();

    const onResize = () => {
      w = canvas.width = window.innerWidth;
      h = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  return (
    <>
      <canvas ref={canvasRef} className="canvas-bg" />
      <main className="wrap">
        <header className="site-header">
          <div className="badge">CYBERPUNK</div>
          <h1 className="site-title glitch" data-text={TITLE}>{TITLE}</h1>
        </header>

        <section className="hero">
          <img src={PHOTO_URL} alt="profile" className="avatar" />
          <h2 className="name neon">{NAME}</h2>
          <p className="tagline">{TAGLINE}</p>
          <div className="divider" />
        </section>

        <section className="bio card">
          <h3 className="card-title">About</h3>
          <p>{BIO}</p>
        </section>

        <section className="contacts card">
          <h3 className="card-title">Contact via QR</h3>
          <p className="hint">Scan a QR below. (Links are intentionally not clickable.)</p>
          <div className="qr-grid">
            {CONTACTS.map((c, idx) => (
              <div key={idx} className="qr-item">
                <div className="qr-box">
                  <QRCode value={c.data} size={148} bgColor="#0a0f0d" fgColor="#22de29" includeMargin={false} />
                </div>
                <span className="qr-label">{c.label}</span>
              </div>
            ))}
          </div>
        </section>

        <section className="card note">
          <p>⚠️ Educational/testing warning — Use responsibly and with proper authorization.</p>
        </section>

        <footer className="footer">
          <span>© {new Date().getFullYear()} {NAME}</span>
        </footer>
      </main>
    </>
  );
}
